<div class="alert alert-info text-center" role="alert">
    <h2 class="text-uppercase text-muted">yor cart is empty</h2>
    <a href="{{ route('home') }}"><h4 class="text-uppercase text-muted">back</h4></a>
</div>
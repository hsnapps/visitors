@extends('layouts.auth')

@section('content')
<h1>404 Not Found</h1>
@endsection
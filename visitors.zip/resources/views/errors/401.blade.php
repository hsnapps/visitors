@extends('layouts.auth')

@section('content')
<h1>401 Unauthorized</h1>
@endsection
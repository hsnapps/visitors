@extends('layouts.auth')

@section('content')
<h1>403 Forbidden</h1>
@endsection
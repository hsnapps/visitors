<a class="uk-float-left uk-button uk-button-xl uk-button-default" href="{{ route('home') }}" onclick="document.getElementById('prepare-payment').submit();">
    <span class="fa fa-chevron-left "></span> &nbsp;&nbsp;Back to Dashboard
</a>
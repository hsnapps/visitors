<h1 style="text-transform: uppercase;">This is a test email</h1>
<h4 style="text-transform: uppercase;">Pleas, don't reply</h4>
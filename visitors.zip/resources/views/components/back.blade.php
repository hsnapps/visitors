<a class="float-left btn btn-lg btn-default" href="{{ route('home') }}">
    <span class="fa fa-chevron-left "></span> &nbsp;&nbsp;Back to Dashboard
</a>
<tr>
    <td colspan="2" style="text-transform: uppercase; font-style: italic;">No Bookings Registered Yet</td>
</tr>
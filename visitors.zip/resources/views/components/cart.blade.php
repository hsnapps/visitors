<a id="cart-btn" 
   href="{{ route('cart') }}" 
   class="float"
   title="Got to cart"><i class="fa fa-2x fa-shopping-cart floating-btn"></i><span class="badge">{{ $cart_count }}</span>
</a>
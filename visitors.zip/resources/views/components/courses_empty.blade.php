<tr>
    <td colspan="2" style="text-transform: uppercase; font-style: italic;">No Courses Registered Yet</td>
</tr>
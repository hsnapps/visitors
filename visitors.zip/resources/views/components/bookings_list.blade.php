<tr>
    <td>{{ sprintf('%d Days', $b->days) }}</td>
    <td></td>
</tr>
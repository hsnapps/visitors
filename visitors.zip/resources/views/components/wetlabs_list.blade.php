<tr>
    <td>{{ $session->wetlab->name }} <small>{{ $session->name }}</small></td>
    <td>{{ substr($session->start_time, 0, 5) }}</td>
</tr>
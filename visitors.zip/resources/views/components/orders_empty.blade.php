<tr>
    <td scope="row" colspan="6"><h2 class="text-muted">you don't have any orders yet!</h2></td>
</tr>
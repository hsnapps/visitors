<tr>
    <td colspan="2" style="text-transform: uppercase; font-style: italic;">No WetLabs Registered Yet</td>
</tr>
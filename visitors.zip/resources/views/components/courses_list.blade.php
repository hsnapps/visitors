<tr>
    <td>{{ $course->name }}</td>
    <td>{{ $course->starts_on->format('d/m/Y') }}</td>
</tr>